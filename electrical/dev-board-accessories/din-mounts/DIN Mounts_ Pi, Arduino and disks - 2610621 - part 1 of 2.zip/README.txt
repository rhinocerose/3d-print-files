DIN Mounts: Pi, Arduino and disks by imstrng on Thingiverse: https://www.thingiverse.com/thing:2610621

Summary:
DIN rail mounts for:Raspberry Pi Zero, 2, 3 and 4ASUS Tinker BoardROCK64NanoPi M4Orange Pi R1Arduino UNOArduino Mega 2560Arduino Mega 2560 + RAMPS 1.42.5 inch hard drive and SSD'sMore information about DIN rail : https://en.wikipedia.org/wiki/DIN_railIf you realy realy realy like my desings, feel free to buy me a beer!Looking forward to see your builds in the Makes section!