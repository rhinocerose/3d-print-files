                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1796770
Bowl stand by Terminus is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

They won't dry out when stacked, so I made this to air-dry bowls. 

These lightweight plastic bowls are approximately 2 inch by 6 inches, "Nordic Ware Microwave Safe Picnic Bowls". They usually come in a set of 2, and are available at places like Walmart and Sears.

With minor tweaking this basic design could adapt to bowls of other profiles and sizes. It would have to be thicker and stronger, and perhaps wider, for glass or ceramic bowls.

I posted a couple of very similar plate-stand projects...
http://www.thingiverse.com/thing:688210
....but hesitated to do one for bowls because it seemed like bowls would be a lot harder to figure out, but it wasn't.

The file is SAE (inches). If metric software thinks it is a tiny 2 x 4 mm, scale it up by a factor of 25.4