                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3647990
My Customized Rubber Band PCB Vice by 416rhinoceros is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Customized version of https://www.thingiverse.com/thing:3446266

Created with Customizer! https://www.thingiverse.com/apps/customizer/run?thing_id=3446266



# Instructions

Using the following options:

length = 130
width = 70
bottom = 1.2
roundness = 5
slotTop = 4
slotBottom = 9
slotHeight = 4
slotTolerance = 0.1
slotPadding = 2
walls = 2
holderHeight = 25
holderThickness = 5
holderThicknessBottom = 8
holderPadding = 2.4
bandSlotDepth = 2
bandSlotHeight = 2
bandSlotOffsetZ = 4
pcbOffsetZ = 2
heightPcb = 1.2
depthPcb = 1.2
heightPcbOuter = 2