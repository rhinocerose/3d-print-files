class UnsupportedDesignTypeException(Exception):
    pass