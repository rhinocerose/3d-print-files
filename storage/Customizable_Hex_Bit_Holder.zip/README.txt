                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:726700
Customizable Hex Bit Holder by xchg_dot_ca is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

https://youtu.be/bbjOygFkFz0

With my customizer you can create hex bit holder of any size for any size of bits.  

You can tweak many parameters, *all dimension are in mm*:  

**Rows** - number of rows, currently maximum is 10  
**Number** - number of columns, currently maximum is 10  
**Base height** - overall heigh of the holder  
**Tolerance** - printer/material tolerance, can be negative, required to compensate specific printer contraction/expansion during print.  
**Extra Padding** - padding between side of the base and bit  
**Rounded corners** - will define slightly rounders corners for better look and print  
**Hole Through** - determines if hole goes completely through the base  
**Slotted** - Make slot to add flex to the walls, slot depth is 75% of the base height  
**Bit Size**, defines bit size ( 6.35mm is 1/4" )  

If you have any issues and suggestions please report in comments.

For more cool things and maker-hacker stuff please check and signup for my youtube channel - <a href=https://www.youtube.com/user/amirnasher>https://www.youtube.com/user/amirnasher</a>

**Tip me if you find this useful !**
**Thank you**